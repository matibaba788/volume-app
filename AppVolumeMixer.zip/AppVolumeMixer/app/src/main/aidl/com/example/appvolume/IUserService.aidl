package com.example.appvolume;

interface IUserService {
    void destroy() = 16777114;
    int[] getActiveUids() = 1;
    void setVolumes(in int[] uids, in float[] volumes) = 2;
}
