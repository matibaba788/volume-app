package com.example.appvolume

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val Accent = Color(0xFF8AB4F8)

@Composable
fun MixerPanel(onInteract: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val master by Mixer.master.collectAsState()

    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color(0xF2202124),
            contentColor = Color.White,
            modifier = Modifier.padding(start = 10.dp)
        ) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${(master * 100).roundToInt()}", fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    VerticalSlider(
                        value = master,
                        onChange = { Mixer.setMaster(it); onInteract() },
                        modifier = Modifier.height(170.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier.size(36.dp).clip(CircleShape)
                            .background(Color(0x33FFFFFF))
                            .clickable { expanded = !expanded; onInteract() },
                        contentAlignment = Alignment.Center
                    ) { Text(if (expanded) "‹" else "›", fontSize = 22.sp) }
                }
                if (expanded) {
                    Spacer(Modifier.width(12.dp))
                    AppList(onInteract)
                }
            }
        }
    }
}

@Composable
private fun AppList(onInteract: () -> Unit) {
    val apps by Mixer.apps.collectAsState()
    val connected by Mixer.connected.collectAsState()
    Column(
        Modifier.width(230.dp).heightIn(max = 280.dp).verticalScroll(rememberScrollState())
    ) {
        Text("Uygulamalar", fontSize = 13.sp, color = Color(0xFFBDC1C6))
        when {
            !connected -> Text("Shizuku bağlı değil.", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            apps.isEmpty() -> Text("Şu an ses çalan uygulama yok.", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
        apps.forEach { app ->
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                app.icon?.let { Image(it, null, Modifier.size(30.dp)) }
                Column(Modifier.padding(start = 10.dp).weight(1f)) {
                    Text("${app.label}  ${(app.volume * 100).roundToInt()}%",
                        fontSize = 12.sp, maxLines = 1)
                    Slider(
                        value = app.volume,
                        onValueChange = { Mixer.setVolume(app.pkg, it); onInteract() },
                        modifier = Modifier.height(28.dp)
                    )
                }
            }
        }
    }
}

/** Dokununca ve sürüklerken anında tepki veren dikey slider (eşik/slop yok). */
@Composable
private fun VerticalSlider(value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val latest = rememberUpdatedState(onChange)
    Box(
        modifier
            .width(48.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0x33FFFFFF))
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    latest.value((1f - down.position.y / size.height).coerceIn(0f, 1f))
                    while (true) {
                        val change = awaitPointerEvent().changes.firstOrNull() ?: break
                        if (!change.pressed) break
                        change.consume()
                        latest.value((1f - change.position.y / size.height).coerceIn(0f, 1f))
                    }
                }
            }
    ) {
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .fillMaxHeight(value.coerceIn(0f, 1f)).background(Accent)
        )
    }
}
