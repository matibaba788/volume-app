package com.example.appvolume

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val Accent = Color(0xFF8AB4F8)

@Composable
fun MixerPanel(onInteract: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    val master by Mixer.master.collectAsState()

    MaterialTheme(colorScheme = darkColorScheme()) {
        AnimatedVisibility(
            visible = visible,
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn()
        ) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = Color(0xEE202124),
                contentColor = Color.White,
                modifier = Modifier.padding(end = 8.dp).animateContentSize()
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (expanded) {
                        AppList(onInteract)
                        Spacer(Modifier.width(12.dp))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${(master * 100).roundToInt()}", fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        VerticalSlider(
                            value = master,
                            onChange = { Mixer.setMaster(it); onInteract() },
                            modifier = Modifier.height(170.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Box(
                            Modifier.size(36.dp).clip(CircleShape)
                                .background(Color(0x33FFFFFF))
                                .clickable { expanded = !expanded; onInteract() },
                            contentAlignment = Alignment.Center
                        ) { Text(if (expanded) "›" else "‹", fontSize = 22.sp) }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppList(onInteract: () -> Unit) {
    val apps by Mixer.apps.collectAsState()
    val connected by Mixer.connected.collectAsState()
    Column(
        Modifier.width(230.dp).heightIn(max = 280.dp).verticalScroll(rememberScrollState())
    ) {
        Text("Uygulamalar", fontSize = 13.sp, color = Color(0xFFBDC1C6))
        when {
            !connected -> Text("Shizuku bağlı değil.", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            apps.isEmpty() -> Text("Şu an ses çalan uygulama yok.", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
        apps.forEach { app ->
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                app.icon?.let { Image(it, null, Modifier.size(30.dp)) }
                Column(Modifier.padding(start = 10.dp).weight(1f)) {
                    Text("${app.label}  ${(app.volume * 100).roundToInt()}%",
                        fontSize = 12.sp, maxLines = 1)
                    Slider(
                        value = app.volume,
                        onValueChange = { Mixer.setVolume(app.pkg, it); onInteract() },
                        modifier = Modifier.height(28.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun VerticalSlider(value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    var h by remember { mutableStateOf(1f) }
    Box(
        modifier
            .width(48.dp)
            .onSizeChanged { h = it.height.toFloat().coerceAtLeast(1f) }
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0x33FFFFFF))
            .pointerInput(Unit) {
                detectTapGestures { o -> onChange((1f - o.y / h).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, _ ->
                    change.consume()
                    onChange((1f - change.position.y / h).coerceIn(0f, 1f))
                }
            }
    ) {
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .fillMaxHeight(value.coerceIn(0f, 1f)).background(Accent)
        )
    }
}
