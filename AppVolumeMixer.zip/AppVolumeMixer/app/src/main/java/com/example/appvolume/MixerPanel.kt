package com.example.appvolume

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun MixerPanel(onInteract: () -> Unit, onClose: () -> Unit) {
    val apps by Mixer.apps.collectAsState()
    val connected by Mixer.connected.collectAsState()
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            tonalElevation = 6.dp,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Uygulama sesleri", style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f))
                    TextButton(onClick = onClose) { Text("Kapat") }
                }
                when {
                    !connected -> Text("Shizuku bağlı değil. Shizuku'yu başlatıp uygulamadan izin ver.")
                    apps.isEmpty() -> Text("Şu an ses çalan uygulama yok.")
                }
                apps.forEach { app ->
                    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        app.icon?.let { Image(it, null, Modifier.size(40.dp)) }
                        Column(Modifier.padding(start = 12.dp).weight(1f)) {
                            Text("${app.label}  ${(app.volume * 100).roundToInt()}%",
                                style = MaterialTheme.typography.bodyMedium)
                            Slider(
                                value = app.volume,
                                onValueChange = { Mixer.setVolume(app.pkg, it); onInteract() }
                            )
                        }
                    }
                }
            }
        }
    }
}
