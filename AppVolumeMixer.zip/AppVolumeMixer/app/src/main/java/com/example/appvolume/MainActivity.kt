package com.example.appvolume

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private var shizukuRunning by mutableStateOf(false)
    private var shizukuGranted by mutableStateOf(false)
    private var a11yOn by mutableStateOf(false)

    private fun refresh() {
        shizukuRunning = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        shizukuGranted = Mixer.hasPermission()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        a11yOn = enabled.contains(packageName)
        if (shizukuGranted) { Mixer.init(this); Mixer.bind() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Mixer.init(this)
        Shizuku.addRequestPermissionResultListener { _, _ -> refresh() }
        lifecycle.addObserver(LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) refresh()
        })
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(24.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Uygulama Sesleri", style = MaterialTheme.typography.headlineSmall)
                        Text("1) Shizuku: " + when {
                            !shizukuRunning -> "çalışmıyor (Shizuku uygulamasından başlat)"
                            !shizukuGranted -> "çalışıyor, izin gerekli"
                            else -> "hazır ✓"
                        })
                        if (shizukuRunning && !shizukuGranted)
                            Button(onClick = { Shizuku.requestPermission(1) }) { Text("Shizuku izni ver") }
                        Text("2) Erişilebilirlik servisi: " + if (a11yOn) "açık ✓" else "kapalı")
                        if (!a11yOn)
                            Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                                Text("Erişilebilirlik ayarlarını aç")
                            }
                        Text("Hazır olunca herhangi bir uygulamada ses tuşuna bas; mikser paneli açılır.",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
