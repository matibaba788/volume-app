package com.example.appvolume

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.IBinder
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import rikka.shizuku.Shizuku
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt

data class AppAudio(
    val uid: Int, val pkg: String, val label: String,
    val icon: ImageBitmap?, val volume: Float
)

object Mixer {
    private lateinit var ctx: Context
    private val prefs by lazy { ctx.getSharedPreferences("volumes", Context.MODE_PRIVATE) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val iconCache = HashMap<String, ImageBitmap?>()
    private val vols = ConcurrentHashMap<String, Float>()
    private val needReset = ConcurrentHashMap.newKeySet<String>()
    private val pushReq = Channel<Unit>(Channel.CONFLATED)
    private var saveJob: Job? = null

    @Volatile var panelVisible = false

    val apps = MutableStateFlow<List<AppAudio>>(emptyList())
    val connected = MutableStateFlow(false)
    /** Genel ses, 0..1 (yüzde / 100). */
    val master = MutableStateFlow(0f)

    private var service: IUserService? = null
    private var lastBindTry = 0L

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            service = IUserService.Stub.asInterface(b); connected.value = true
            scope.launch { tick() }
        }
        override fun onServiceDisconnected(n: ComponentName) {
            service = null; connected.value = false
        }
    }

    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        prefs.all.forEach { (k, v) -> if (v is Float) vols[k] = v }
        Shizuku.addBinderReceivedListenerSticky { bind() }
        scope.launch { for (x in pushReq) push() }
    }

    // ================= Genel (medya) ses =================
    // Sistem sesi ~15 kademelidir. %1 hassasiyet için: sistem kademesi yukarı yuvarlanır,
    // aradaki fark çalan uygulamalara Shizuku ile çarpan (masterMult) olarak uygulanır.
    // Shizuku yoksa kademeli (kaba) çalışır.
    private val am by lazy { ctx.getSystemService(AudioManager::class.java) }
    @Volatile private var masterPct = 0
    @Volatile private var masterMult = 1f
    @Volatile private var expectedIdx = -1
    @Volatile private var expectedStream = -1

    private fun stream() =
        if (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION)
            AudioManager.STREAM_VOICE_CALL else AudioManager.STREAM_MUSIC

    private fun maxOf(s: Int) = am.getStreamMaxVolume(s).coerceAtLeast(1)
    private fun fineMode(s: Int) = service != null && s == AudioManager.STREAM_MUSIC

    private fun multFor(pct: Int, idx: Int, max: Int): Float =
        if (idx <= 0) 1f else (pct * max / 100f / idx).coerceIn(0f, 1f)

    private fun setMult(m: Float) {
        if (abs(m - masterMult) < 0.0005f) return
        masterMult = m
        apps.value.forEach { needReset.add(it.pkg) } // eski çarpan geri alınabilsin
        pushReq.trySend(Unit)
    }

    /** Sistemdeki gerçek sesi okur; dışarıdan değiştiyse yüzdeyi ona göre eşitler. */
    fun refreshMaster() {
        try {
            val s = stream(); val max = maxOf(s); val idx = am.getStreamVolume(s)
            if (s != expectedStream || idx != expectedIdx) {
                masterPct = (idx * 100f / max).roundToInt()
                expectedIdx = idx; expectedStream = s
            }
            setMult(if (fineMode(s)) multFor(masterPct, idx, max) else 1f)
            master.value = masterPct / 100f
        } catch (_: Throwable) {}
    }

    private fun setStreamIndex(s: Int, idx: Int, max: Int) {
        try { if (idx != am.getStreamVolume(s)) am.setStreamVolume(s, idx, 0) } catch (_: Throwable) {}
        // Bazı telefonlar setStreamVolume'u yok sayıyor: ses tuşuyla aynı yolla kademe kademe ayarla.
        try {
            var cur = am.getStreamVolume(s); var guard = 0
            while (cur != idx && guard++ < max) {
                am.adjustStreamVolume(s,
                    if (idx > cur) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
                val now = am.getStreamVolume(s)
                if (now == cur) break
                cur = now
            }
        } catch (_: Throwable) {}
    }

    fun setMasterPct(p: Int) {
        try {
            val s = stream(); val max = maxOf(s)
            val fine = fineMode(s)
            var pct = p.coerceIn(0, 100)
            val idx = if (fine) ceil(pct * max / 100f - 1e-4f).toInt().coerceIn(0, max)
                      else (pct * max / 100f).roundToInt().coerceIn(0, max)
            if (!fine) pct = (idx * 100f / max).roundToInt()
            setStreamIndex(s, idx, max)
            masterPct = pct; expectedIdx = idx; expectedStream = s
        } catch (_: Throwable) {}
        refreshMaster()
    }

    /** Slider: %1 hassasiyet. */
    fun setMaster(frac: Float) = setMasterPct((frac * 100f).roundToInt())

    /** Ses tuşu: %5 adım (Shizuku yoksa sistem kademesi). */
    fun stepMaster(up: Boolean) {
        refreshMaster()
        val s = try { stream() } catch (_: Throwable) { return }
        if (fineMode(s)) {
            setMasterPct(masterPct + if (up) 5 else -5)
        } else {
            try {
                am.adjustStreamVolume(s,
                    if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
            } catch (_: Throwable) {}
            refreshMaster()
        }
    }

    // ================= Uygulama bazlı ses =================
    fun hasPermission() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun bind() {
        if (service != null || !hasPermission()) return
        val now = System.currentTimeMillis()
        if (now - lastBindTry < 4000) return
        lastBindTry = now
        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, UserService::class.java.name))
            .processNameSuffix("mixer").daemon(false).version(1)
        try { Shizuku.bindUserService(args, conn) } catch (_: Throwable) {}
    }

    private fun volumeOf(pkg: String) = vols[pkg] ?: 1f
    private fun hasCustom() =
        masterMult != 1f || needReset.isNotEmpty() || vols.values.any { it != 1f }

    fun setVolume(pkg: String, v: Float) {
        val value = if (v > 0.98f) 1f else v
        vols[pkg] = value
        if (value == 1f) needReset.add(pkg)
        apps.value = apps.value.map { if (it.pkg == pkg) it.copy(volume = value) else it }
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(400)
            prefs.edit().apply { vols.forEach { (k, x) -> putFloat(k, x) } }.apply()
        }
        pushReq.trySend(Unit)
    }

    /** Etkin ses = uygulama sesi × genel çarpan. Sadece %100 olmayanlara (veya sıfırlanacaklara) gönderilir. */
    private fun push() {
        val s = service ?: return
        val mult = masterMult
        val list = apps.value.map { it to it.volume * mult }
            .filter { (a, e) -> e != 1f || a.pkg in needReset }
        if (list.isEmpty()) return
        try {
            s.setVolumes(list.map { it.first.uid }.toIntArray(), list.map { it.second }.toFloatArray())
            list.forEach { (a, e) -> if (e == 1f) needReset.remove(a.pkg) }
        } catch (_: Throwable) {}
    }

    /** Çalma durumu değişince çağrılır (polling yok). Gereksizse hiçbir iş yapmaz. */
    suspend fun tick() = withContext(Dispatchers.IO) {
        if (!panelVisible && !hasCustom()) return@withContext
        refreshMaster()
        val s = service ?: return@withContext
        val uids = try { s.activeUids } catch (_: Throwable) { return@withContext }
        val pm = ctx.packageManager
        val list = uids.filter { it >= 10000 }.mapNotNull { uid ->
            val pkg = pm.getPackagesForUid(uid)?.firstOrNull() ?: return@mapNotNull null
            if (pkg == ctx.packageName) return@mapNotNull null
            val info = try { pm.getApplicationInfo(pkg, 0) } catch (_: Throwable) { return@mapNotNull null }
            val icon = iconCache.getOrPut(pkg) {
                try { pm.getApplicationIcon(info).toBitmap(96, 96).asImageBitmap() } catch (_: Throwable) { null }
            }
            AppAudio(uid, pkg, pm.getApplicationLabel(info).toString(), icon, volumeOf(pkg))
        }
        apps.value = list
        needReset.retainAll(list.map { it.pkg }.toSet())
        push()
    }
}
