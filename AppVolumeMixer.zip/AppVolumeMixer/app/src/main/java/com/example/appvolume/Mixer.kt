package com.example.appvolume

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.IBinder
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.roundToInt
import rikka.shizuku.Shizuku

data class AppAudio(
    val uid: Int, val pkg: String, val label: String,
    val icon: ImageBitmap?, val volume: Float
)

object Mixer {
    private lateinit var ctx: Context
    private val prefs by lazy { ctx.getSharedPreferences("volumes", Context.MODE_PRIVATE) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val iconCache = HashMap<String, ImageBitmap?>()

    val apps = MutableStateFlow<List<AppAudio>>(emptyList())
    val connected = MutableStateFlow(false)

    // ---- Genel (master) ses ----
    val master = MutableStateFlow(0f)
    private val am by lazy { ctx.getSystemService(AudioManager::class.java) }
    private fun stream() =
        if (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION)
            AudioManager.STREAM_VOICE_CALL else AudioManager.STREAM_MUSIC

    fun refreshMaster() {
        try {
            val s = stream(); val max = am.getStreamMaxVolume(s).coerceAtLeast(1)
            master.value = am.getStreamVolume(s).toFloat() / max
        } catch (_: Throwable) {}
    }
    fun setMaster(frac: Float) {
        try {
            val s = stream(); val max = am.getStreamMaxVolume(s).coerceAtLeast(1)
            am.setStreamVolume(s, (frac * max).roundToInt().coerceIn(0, max), 0)
        } catch (_: Throwable) {}
        refreshMaster()
    }
    fun stepMaster(up: Boolean) {
        try {
            am.adjustStreamVolume(stream(),
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
        } catch (_: Throwable) {}
        refreshMaster()
    }
    private var service: IUserService? = null
    private var lastBindTry = 0L

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            service = IUserService.Stub.asInterface(b); connected.value = true
        }
        override fun onServiceDisconnected(n: ComponentName) {
            service = null; connected.value = false
        }
    }

    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        Shizuku.addBinderReceivedListenerSticky { bind() }
    }

    fun hasPermission() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun bind() {
        if (service != null || !hasPermission()) return
        val now = System.currentTimeMillis()
        if (now - lastBindTry < 4000) return
        lastBindTry = now
        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, UserService::class.java.name))
            .processNameSuffix("mixer").daemon(false).version(1)
        try { Shizuku.bindUserService(args, conn) } catch (_: Throwable) {}
    }

    fun volumeOf(pkg: String) = prefs.getFloat(pkg, 1f)

    fun setVolume(pkg: String, v: Float) {
        prefs.edit().putFloat(pkg, v).apply()
        apps.value = apps.value.map { if (it.pkg == pkg) it.copy(volume = v) else it }
        scope.launch { push() }
    }

    private fun push() {
        val s = service ?: return
        val list = apps.value
        try { s.setVolumes(list.map { it.uid }.toIntArray(), list.map { it.volume }.toFloatArray()) }
        catch (_: Throwable) {}
    }

    /** Her ~0.5 sn çağrılır: çalan uygulamaları bulur, kayıtlı seviyeleri uygular. */
    suspend fun tick() = withContext(Dispatchers.IO) {
        refreshMaster()
        bind()
        val s = service ?: return@withContext
        val uids = try { s.activeUids } catch (_: Throwable) { return@withContext }
        val pm = ctx.packageManager
        val list = uids.filter { it >= 10000 }.mapNotNull { uid ->
            val pkg = pm.getPackagesForUid(uid)?.firstOrNull() ?: return@mapNotNull null
            if (pkg == ctx.packageName) return@mapNotNull null
            val info = try { pm.getApplicationInfo(pkg, 0) } catch (_: Throwable) { return@mapNotNull null }
            val icon = iconCache.getOrPut(pkg) {
                try { pm.getApplicationIcon(info).toBitmap(96, 96).asImageBitmap() } catch (_: Throwable) { null }
            }
            AppAudio(uid, pkg, pm.getApplicationLabel(info).toString(), icon, volumeOf(pkg))
        }
        apps.value = list
        push()
    }
}
