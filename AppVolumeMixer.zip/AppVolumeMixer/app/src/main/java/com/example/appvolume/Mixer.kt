package com.example.appvolume

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.IBinder
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import rikka.shizuku.Shizuku
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

data class AppAudio(
    val uid: Int, val pkg: String, val label: String,
    val icon: ImageBitmap?, val volume: Float
)

object Mixer {
    private lateinit var ctx: Context
    private val prefs by lazy { ctx.getSharedPreferences("volumes", Context.MODE_PRIVATE) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val iconCache = HashMap<String, ImageBitmap?>()
    private val vols = ConcurrentHashMap<String, Float>()
    private val needReset = ConcurrentHashMap.newKeySet<String>()
    private val pushReq = Channel<Unit>(Channel.CONFLATED)
    private var saveJob: Job? = null

    @Volatile var panelVisible = false

    val apps = MutableStateFlow<List<AppAudio>>(emptyList())
    val connected = MutableStateFlow(false)
    val master = MutableStateFlow(0f)

    private var service: IUserService? = null
    private var lastBindTry = 0L

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            service = IUserService.Stub.asInterface(b); connected.value = true
            scope.launch { tick() }
        }
        override fun onServiceDisconnected(n: ComponentName) {
            service = null; connected.value = false
        }
    }

    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        prefs.all.forEach { (k, v) -> if (v is Float) vols[k] = v }
        Shizuku.addBinderReceivedListenerSticky { bind() }
        scope.launch { for (x in pushReq) push() }
    }

    // ---------------- Genel (medya) ses ----------------
    private val am by lazy { ctx.getSystemService(AudioManager::class.java) }
    private fun stream() =
        if (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION)
            AudioManager.STREAM_VOICE_CALL else AudioManager.STREAM_MUSIC

    fun refreshMaster() {
        try {
            val s = stream(); val max = am.getStreamMaxVolume(s).coerceAtLeast(1)
            master.value = am.getStreamVolume(s).toFloat() / max
        } catch (_: Throwable) {}
    }

    fun setMaster(frac: Float) {
        try {
            val s = stream(); val max = am.getStreamMaxVolume(s).coerceAtLeast(1)
            val target = (frac * max).roundToInt().coerceIn(0, max)
            if (target != am.getStreamVolume(s)) am.setStreamVolume(s, target, 0)
            master.value = target.toFloat() / max
        } catch (_: Throwable) {}
    }

    fun stepMaster(up: Boolean) {
        try {
            am.adjustStreamVolume(stream(),
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
        } catch (_: Throwable) {}
        refreshMaster()
    }

    // ---------------- Uygulama bazlı ses ----------------
    fun hasPermission() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun bind() {
        if (service != null || !hasPermission()) return
        val now = System.currentTimeMillis()
        if (now - lastBindTry < 4000) return
        lastBindTry = now
        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, UserService::class.java.name))
            .processNameSuffix("mixer").daemon(false).version(1)
        try { Shizuku.bindUserService(args, conn) } catch (_: Throwable) {}
    }

    private fun volumeOf(pkg: String) = vols[pkg] ?: 1f
    private fun hasCustom() = needReset.isNotEmpty() || vols.values.any { it != 1f }

    fun setVolume(pkg: String, v: Float) {
        val value = if (v > 0.98f) 1f else v
        vols[pkg] = value
        if (value == 1f) needReset.add(pkg)
        apps.value = apps.value.map { if (it.pkg == pkg) it.copy(volume = value) else it }
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(400)
            prefs.edit().apply { vols.forEach { (k, x) -> putFloat(k, x) } }.apply()
        }
        pushReq.trySend(Unit)
    }

    /** Sadece değiştirilmiş (%100 olmayan) uygulamalara gönderir. */
    private fun push() {
        val s = service ?: return
        val list = apps.value.filter { it.volume != 1f || it.pkg in needReset }
        if (list.isEmpty()) return
        try {
            s.setVolumes(list.map { it.uid }.toIntArray(), list.map { it.volume }.toFloatArray())
            list.forEach { if (it.volume == 1f) needReset.remove(it.pkg) }
        } catch (_: Throwable) {}
    }

    /**
     * Çalma durumu değiştiğinde çağrılır (polling yok). Panel kapalıysa ve
     * özel ses ayarı yoksa hiçbir iş yapmaz.
     */
    suspend fun tick() = withContext(Dispatchers.IO) {
        if (!panelVisible && !hasCustom()) return@withContext
        refreshMaster()
        val s = service ?: return@withContext
        val uids = try { s.activeUids } catch (_: Throwable) { return@withContext }
        val pm = ctx.packageManager
        val list = uids.filter { it >= 10000 }.mapNotNull { uid ->
            val pkg = pm.getPackagesForUid(uid)?.firstOrNull() ?: return@mapNotNull null
            if (pkg == ctx.packageName) return@mapNotNull null
            val info = try { pm.getApplicationInfo(pkg, 0) } catch (_: Throwable) { return@mapNotNull null }
            val icon = iconCache.getOrPut(pkg) {
                try { pm.getApplicationIcon(info).toBitmap(96, 96).asImageBitmap() } catch (_: Throwable) { null }
            }
            AppAudio(uid, pkg, pm.getApplicationLabel(info).toString(), icon, volumeOf(pkg))
        }
        apps.value = list
        needReset.retainAll(list.map { it.pkg }.toSet())
        push()
    }
}
