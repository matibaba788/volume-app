package com.example.appvolume

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.*

private class Owner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val lr = LifecycleRegistry(this)
    private val ssc = SavedStateRegistryController.create(this)
    override val viewModelStore = ViewModelStore()
    init { ssc.performRestore(null); lr.currentState = Lifecycle.State.RESUMED }
    override val lifecycle: Lifecycle get() = lr
    override val savedStateRegistry: SavedStateRegistry get() = ssc.savedStateRegistry
}

class VolumeKeyService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var view: ComposeView? = null
    private val hideRunnable = Runnable { hidePanel() }

    override fun onServiceConnected() {
        Mixer.init(applicationContext)
        scope.launch { while (isActive) { Mixer.tick(); delay(500) } }
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN &&
            (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP || e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            showPanel()
        }
        return false // normal ses davranışı aynen çalışsın
    }

    private fun showPanel() {
        resetTimer()
        if (view != null) return
        val owner = Owner()
        val v = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setContent { MixerPanel(onInteract = { resetTimer() }, onClose = { hidePanel() }) }
            setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_OUTSIDE) hidePanel()
                false
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP }
        getSystemService(WindowManager::class.java).addView(v, lp)
        view = v
    }

    private fun resetTimer() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 4000)
    }

    private fun hidePanel() {
        handler.removeCallbacks(hideRunnable)
        view?.let { try { getSystemService(WindowManager::class.java).removeView(it) } catch (_: Throwable) {} }
        view = null
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { hidePanel(); scope.cancel(); super.onDestroy() }
}
