package com.example.appvolume

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.*

private class Owner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val lr = LifecycleRegistry(this)
    private val ssc = SavedStateRegistryController.create(this)
    override val viewModelStore = ViewModelStore()
    init { ssc.performRestore(null); lr.currentState = Lifecycle.State.RESUMED }
    override val lifecycle: Lifecycle get() = lr
    override val savedStateRegistry: SavedStateRegistry get() = ssc.savedStateRegistry
    fun destroy() { lr.currentState = Lifecycle.State.DESTROYED; viewModelStore.clear() }
}

class VolumeKeyService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var view: ComposeView? = null
    private var owner: Owner? = null
    private var tickJob: Job? = null
    private val hideRunnable = Runnable { hidePanel() }
    private lateinit var audio: AudioManager

    // Polling yok: sadece ses çalma durumu değişince tetiklenir.
    private val playbackCb = object : AudioManager.AudioPlaybackCallback() {
        override fun onPlaybackConfigChanged(configs: MutableList<AudioPlaybackConfiguration>?) {
            requestTick()
        }
    }

    /**
     * Şarkı/video değişince uygulama yeni oynatıcı açar ve bazen sesi kendi de ayarlar.
     * Bu yüzden önce hemen, sonra kısa aralıklarla birkaç kez kayıtlı seviyeleri tekrar uygularız.
     * (Olay bazlı: sadece çalma durumu değişince çalışır.)
     */
    private fun requestTick() {
        tickJob?.cancel()
        tickJob = scope.launch {
            Mixer.requestPush()
            for (d in longArrayOf(150, 350, 700)) { delay(d); Mixer.tick() }
        }
    }

    override fun onServiceConnected() {
        Mixer.init(applicationContext)
        audio = getSystemService(AudioManager::class.java)
        audio.registerAudioPlaybackCallback(playbackCb, handler)
        scope.launch { while (isActive) { Mixer.bind(); delay(10_000) } }
        requestTick()
    }

    // Tuşa basılı tutunca sürekli artır/azalt
    private var heldUp: Boolean? = null
    private var repeatCount = 0
    private val repeatRunnable = object : Runnable {
        override fun run() {
            val up = heldUp ?: return
            if (++repeatCount > 120) { heldUp = null; return } // güvenlik sınırı (~13 sn)
            Mixer.stepMaster(up)
            showPanel()
            handler.postDelayed(this, 110)
        }
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode != KeyEvent.KEYCODE_VOLUME_UP && e.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN)
            return false
        val up = e.keyCode == KeyEvent.KEYCODE_VOLUME_UP
        when (e.action) {
            KeyEvent.ACTION_DOWN -> if (e.repeatCount == 0) {
                handler.removeCallbacks(repeatRunnable)
                heldUp = up; repeatCount = 0
                Mixer.stepMaster(up)          // tek basış: %5
                showPanel()
                handler.postDelayed(repeatRunnable, 400) // basılı tutma
            }
            KeyEvent.ACTION_UP -> { heldUp = null; handler.removeCallbacks(repeatRunnable) }
        }
        return true // sistemin kendi ses paneli çıkmasın
    }

    private fun showPanel() {
        resetTimer()
        if (view != null) return
        Mixer.panelVisible = true
        requestTick()
        val o = Owner()
        owner = o
        val v = ComposeView(this).apply {
            setViewTreeLifecycleOwner(o)
            setViewTreeSavedStateRegistryOwner(o)
            setViewTreeViewModelStoreOwner(o)
            setContent { MixerPanel(onInteract = { resetTimer() }) }
            setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_OUTSIDE) hidePanel()
                false
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
        getSystemService(WindowManager::class.java).addView(v, lp)
        view = v
    }

    private fun resetTimer() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 5000)
    }

    private fun hidePanel() {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(repeatRunnable); heldUp = null
        Mixer.panelVisible = false
        view?.let { try { getSystemService(WindowManager::class.java).removeView(it) } catch (_: Throwable) {} }
        view = null
        owner?.destroy(); owner = null
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        hidePanel()
        try { audio.unregisterAudioPlaybackCallback(playbackCb) } catch (_: Throwable) {}
        scope.cancel()
        super.onDestroy()
    }
}
