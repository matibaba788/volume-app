package com.example.appvolume

import android.os.IBinder
import org.lsposed.hiddenapibypass.HiddenApiBypass
import kotlin.system.exitProcess

/** Shizuku tarafından shell yetkisiyle çalıştırılır. */
class UserService : IUserService.Stub() {

    init {
        try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {}
    }

    private val audioService: Any by lazy {
        val sm = Class.forName("android.os.ServiceManager")
        val binder = sm.getMethod("getService", String::class.java).invoke(null, "audio") as IBinder
        Class.forName("android.media.IAudioService\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
    }

    private fun configs(): List<Any> {
        val m = Class.forName("android.media.IAudioService")
            .getMethod("getActivePlaybackConfigurations")
        return (m.invoke(audioService) as? List<*>)?.filterNotNull() ?: emptyList()
    }

    private fun uidOf(c: Any) = c.javaClass.getMethod("getClientUid").invoke(c) as Int
    private fun stateOf(c: Any) = c.javaClass.getMethod("getPlayerState").invoke(c) as Int

    override fun getActiveUids(): IntArray = try {
        configs().filter { stateOf(it) == 2 /* PLAYER_STATE_STARTED */ }
            .map { uidOf(it) }.distinct().toIntArray()
    } catch (t: Throwable) { IntArray(0) }

    override fun setVolumes(uids: IntArray, volumes: FloatArray) {
        val map = uids.zip(volumes.toList()).toMap()
        try {
            for (c in configs()) {
                val v = map[uidOf(c)] ?: continue
                try {
                    val proxy = c.javaClass.getMethod("getPlayerProxy").invoke(c) ?: continue
                    proxy.javaClass.getMethod("setVolume", Float::class.javaPrimitiveType)
                        .invoke(proxy, v)
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    override fun destroy() { exitProcess(0) }
}
