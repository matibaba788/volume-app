package com.example.appvolume

import android.os.IBinder
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.lang.reflect.Method
import kotlin.system.exitProcess

/** Shizuku tarafından shell yetkisiyle çalıştırılır. Reflection metodları önbelleğe alınır. */
class UserService : IUserService.Stub() {

    init {
        try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {}
    }

    private val audioService: Any by lazy {
        val sm = Class.forName("android.os.ServiceManager")
        val binder = sm.getMethod("getService", String::class.java).invoke(null, "audio") as IBinder
        Class.forName("android.media.IAudioService\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
    }
    private val getConfigsM: Method by lazy {
        Class.forName("android.media.IAudioService").getMethod("getActivePlaybackConfigurations")
    }
    private var uidM: Method? = null
    private var stateM: Method? = null
    private var proxyM: Method? = null
    private var volM: Method? = null

    private fun configs(): List<Any> =
        (getConfigsM.invoke(audioService) as? List<*>)?.filterNotNull() ?: emptyList()

    private fun uidOf(c: Any): Int =
        (uidM ?: c.javaClass.getMethod("getClientUid").also { uidM = it }).invoke(c) as Int

    private fun stateOf(c: Any): Int =
        (stateM ?: c.javaClass.getMethod("getPlayerState").also { stateM = it }).invoke(c) as Int

    override fun getActiveUids(): IntArray = try {
        configs().filter { stateOf(it) == 2 /* STARTED */ }
            .map { uidOf(it) }.distinct().toIntArray()
    } catch (t: Throwable) { IntArray(0) }

    override fun setVolumes(uids: IntArray, volumes: FloatArray) {
        val map = HashMap<Int, Float>()
        for (i in uids.indices) map[uids[i]] = volumes[i]
        try {
            for (c in configs()) {
                val v = map[uidOf(c)] ?: continue
                try {
                    val pm = proxyM ?: c.javaClass.getMethod("getPlayerProxy").also { proxyM = it }
                    val proxy = pm.invoke(c) ?: continue
                    val vm = volM ?: proxy.javaClass
                        .getMethod("setVolume", Float::class.javaPrimitiveType).also { volM = it }
                    vm.invoke(proxy, v)
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    override fun destroy() { exitProcess(0) }
}
